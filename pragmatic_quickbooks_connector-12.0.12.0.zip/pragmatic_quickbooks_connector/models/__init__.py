# -*- coding: utf-8 -*-

from . import account
from . import account_payment_term
from . import account_tax
from . import product
from . import res_company
from . import res_partner
from . import account_invoice
from . import details
from . import export_sale_order
from . import export_purchase_order
from . import export_dept
from . import export_emp
from . import res_config_settings
